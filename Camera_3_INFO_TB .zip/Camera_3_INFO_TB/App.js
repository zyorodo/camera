
import { useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library/legacy';

export default function App() {
  const camera = useRef(null);
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [galleryPermission, requestGalleryPermission] =
    MediaLibrary.usePermissions({ writeOnly: true });
  const [salvando, setSalvando] = useState(false);

  async function pedirPermissoes() {
    const cameraResult = cameraPermission?.granted
      ? cameraPermission
      : await requestCameraPermission();

    if (!cameraResult?.granted) {
      Alert.alert(
        'Permissão necessária',
        'Permita o acesso à câmera para tirar fotos.'
      );
      return;
    }

    const galleryResult = galleryPermission?.granted
      ? galleryPermission
      : await requestGalleryPermission();

    if (!galleryResult?.granted) {
      Alert.alert(
        'Permissão necessária',
        'Permita o acesso à galeria para salvar as fotos.'
      );
    }
  }

  async function tirarFoto() {
    if (!camera.current || salvando) return;

    setSalvando(true);

    try {
      const foto = await camera.current.takePictureAsync({ quality: 0.8 });

      if (!foto?.uri) {
        throw new Error('A câmera não retornou o arquivo da foto.');
      }

      await MediaLibrary.saveToLibraryAsync(foto.uri);

      Alert.alert('Foto salva', 'A foto foi salva na galeria do dispositivo.');
    } catch (error) {
      Alert.alert(
        'Erro ao salvar foto',
        String(error?.message || error)
      );
      console.log('Erro ao tirar ou salvar foto:', error);
    } finally {
      setSalvando(false);
    }
  }

  const permissoesCarregadas = cameraPermission && galleryPermission;
  const temPermissoes =
    cameraPermission?.granted && galleryPermission?.granted;

  if (!permissoesCarregadas) {
    return (
      <View style={styles.carregando}>
        <ActivityIndicator size="large" color="#38bdf8" />
        <Text style={styles.textoCarregando}>Carregando câmera...</Text>
      </View>
    );
  }

  if (!temPermissoes) {
    return (
      <View style={styles.permissaoContainer}>
        <StatusBar barStyle="light-content" />

        <View style={styles.iconeCamera}>
          <Text style={styles.emojiCamera}>📸</Text>
        </View>

        <Text style={styles.titulo}>Minha Câmera</Text>

        <Text style={styles.descricao}>
          Para tirar fotos e salvá-las, precisamos de acesso à câmera e à
          galeria.
        </Text>

        <TouchableOpacity
          style={styles.botaoPermissao}
          onPress={pedirPermissoes}
        >
          <Text style={styles.textoBotaoPermissao}>Permitir acesso</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.cabecalho}>
        <View>
          <Text style={styles.tituloCabecalho}>Minha Câmera</Text>
          <Text style={styles.subtitulo}>Registre seus momentos</Text>
        </View>

        <Text style={styles.emojiCabecalho}>✦</Text>
      </View>

      <View style={styles.cameraContainer}>
        <CameraView ref={camera} style={styles.camera} facing="back" />

        <View pointerEvents="none" style={styles.marcaSuperiorEsquerda} />
        <View pointerEvents="none" style={styles.marcaSuperiorDireita} />
        <View pointerEvents="none" style={styles.marcaInferiorEsquerda} />
        <View pointerEvents="none" style={styles.marcaInferiorDireita} />
      </View>

      <View style={styles.rodape}>
        <Text style={styles.instrucao}>
          Toque no botão para tirar uma foto
        </Text>

        <TouchableOpacity
          style={[styles.botaoFoto, salvando && styles.botaoDesativado]}
          onPress={tirarFoto}
          disabled={salvando}
          accessibilityLabel="Tirar foto"
        >
          {salvando ? (
            <ActivityIndicator color="#0f172a" />
          ) : (
            <View style={styles.circuloInterno} />
          )}
        </TouchableOpacity>

        <Text style={styles.textoGaleria}>
          As fotos serão salvas na galeria
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0b1120',
    paddingHorizontal: 18,
    paddingTop: 48,
    paddingBottom: 22,
  },
  cabecalho: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 22,
  },
  tituloCabecalho: {
    color: '#f8fafc',
    fontSize: 25,
    fontWeight: '700',
  },
  subtitulo: {
    color: '#94a3b8',
    fontSize: 14,
    marginTop: 5,
  },
  emojiCabecalho: {
    color: '#38bdf8',
    fontSize: 28,
  },
  cameraContainer: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: 26,
    backgroundColor: '#1e293b',
    position: 'relative',
  },
  camera: {
    flex: 1,
  },
  marcaSuperiorEsquerda: {
    position: 'absolute',
    top: 16,
    left: 16,
    width: 28,
    height: 28,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderColor: '#ffffff',
    borderTopLeftRadius: 8,
  },
  marcaSuperiorDireita: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 28,
    height: 28,
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderColor: '#ffffff',
    borderTopRightRadius: 8,
  },
  marcaInferiorEsquerda: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    width: 28,
    height: 28,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderColor: '#ffffff',
    borderBottomLeftRadius: 8,
  },
  marcaInferiorDireita: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    width: 28,
    height: 28,
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderColor: '#ffffff',
    borderBottomRightRadius: 8,
  },
  rodape: {
    alignItems: 'center',
    paddingTop: 22,
  },
  instrucao: {
    color: '#cbd5e1',
    fontSize: 14,
    marginBottom: 17,
  },
  botaoFoto: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: '#38bdf8',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 5,
    borderColor: '#e0f2fe',
  },
  botaoDesativado: {
    opacity: 0.7,
  },
  circuloInterno: {
    width: 54,
    height: 54,
    borderRadius: 27,
    borderWidth: 3,
    borderColor: '#0b1120',
    backgroundColor: '#38bdf8',
  },
  textoGaleria: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 14,
  },
  permissaoContainer: {
    flex: 1,
    backgroundColor: '#0b1120',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 28,
  },
  iconeCamera: {
    width: 94,
    height: 94,
    borderRadius: 28,
    backgroundColor: '#172554',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  emojiCamera: {
    fontSize: 43,
  },
  titulo: {
    color: '#f8fafc',
    fontSize: 27,
    fontWeight: '700',
    textAlign: 'center',
  },
  descricao: {
    color: '#94a3b8',
    fontSize: 15,
    lineHeight: 23,
    textAlign: 'center',
    marginTop: 12,
    marginBottom: 26,
  },
  botaoPermissao: {
    backgroundColor: '#38bdf8',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 14,
  },
  textoBotaoPermissao: {
    color: '#0b1120',
    fontSize: 15,
    fontWeight: '700',
  },
  carregando: {
    flex: 1,
    backgroundColor: '#0b1120',
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoCarregando: {
    color: '#f8fafc',
    marginTop: 12,
  },
});
