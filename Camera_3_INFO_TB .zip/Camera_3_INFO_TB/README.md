# Minha Câmera — atividade ETEC

Aplicativo em React Native com Expo para abrir a câmera, tirar uma foto e salvá-la na galeria do celular.

## Como executar

1. Instale o Node.js 22.13 ou superior no computador.
2. Extraia este ZIP e abra o terminal dentro da pasta `Camera_3_INFO_TB-master`.
3. Instale as dependências:

```bash
npm install
```

4. Inicie o Expo:

```bash
npx expo start
```

5. Abra o projeto em um dispositivo compatível. Conceda as permissões de câmera e galeria, tire uma foto e confira se ela foi salva.

## Observação

O projeto já declara `expo-camera` e `expo-media-library` no `package.json`, com versões compatíveis com o Expo SDK 57. A confirmação final depende de executar e testar em um celular físico.
